(function($){
    $.fn.reveal = function() {
        return this.each(function() {

        });	
    };
})(jQuery);
