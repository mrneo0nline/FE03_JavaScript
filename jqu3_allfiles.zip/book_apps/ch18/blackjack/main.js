"use strict";
$( document ).ready(function() {
    $("#blackjack").blackjack({
        playerName: "Mary"
    });
});