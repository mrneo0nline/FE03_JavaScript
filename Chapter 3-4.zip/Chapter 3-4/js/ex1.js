/* var $ = function(id){
	return document.getElementById(id);
}

var ex1 = function(){
	var a = prompt("Input number a:");
	var b = prompt("Input number b:");
	var c;
	// alert("You inputted: a = " + a +", b = " + b);
	c = a;
	b = c;
	a = b;
} */